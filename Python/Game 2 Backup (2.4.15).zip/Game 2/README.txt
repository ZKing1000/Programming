Dependencies:
	Python (I'm using 2.7.5, but I don't know the spectrum which can be used)
	PIL (Check ./lib/collisionDetection.py)
	Pygame (I'm using 1.9.1)
