import os
for x in range(30):
	os.system("mkdir "+str(x))

